
import os, sqlite3, secrets
from datetime import datetime
from functools import wraps
from flask import Flask, request, redirect, url_for, render_template, session, flash, send_from_directory
from werkzeug.utils import secure_filename

BASE=os.path.dirname(os.path.abspath(__file__))
DATA_DIR=os.environ.get("DATA_DIR", BASE)
os.makedirs(DATA_DIR, exist_ok=True)
DB=os.path.join(DATA_DIR,"pathology_lab.db")
UPLOAD=os.path.join(DATA_DIR,"uploads")
os.makedirs(UPLOAD,exist_ok=True)
app=Flask(__name__)
app.secret_key=os.environ.get("SECRET_KEY") or secrets.token_hex(32)
app.config["MAX_CONTENT_LENGTH"]=5*1024*1024
ADMIN_PASSWORD=os.environ.get("ADMIN_PASSWORD","ChangeMe123!")
CATALOG="""HEMATOLOGY|CBC
HEMATOLOGY|Hemoglobin (Hb)
HEMATOLOGY|TLC
HEMATOLOGY|DLC
HEMATOLOGY|RBC Count
HEMATOLOGY|Platelet Count
HEMATOLOGY|PCV / Hematocrit
HEMATOLOGY|MCV
HEMATOLOGY|MCH
HEMATOLOGY|MCHC
HEMATOLOGY|RDW-CV
HEMATOLOGY|RDW-SD
HEMATOLOGY|MPV
HEMATOLOGY|PDW
HEMATOLOGY|PCT
HEMATOLOGY|ESR
HEMATOLOGY|Absolute Neutrophil Count
HEMATOLOGY|Absolute Lymphocyte Count
HEMATOLOGY|Absolute Eosinophil Count
HEMATOLOGY|Absolute Basophil Count
HEMATOLOGY|Absolute Monocyte Count
HEMATOLOGY|Peripheral Blood Smear (PBS)
HEMATOLOGY|Reticulocyte Count
HEMATOLOGY|Bleeding Time (BT)
HEMATOLOGY|Clotting Time (CT)
HEMATOLOGY|Prothrombin Time (PT)
HEMATOLOGY|INR
HEMATOLOGY|APTT
HEMATOLOGY|Fibrinogen
HEMATOLOGY|D-Dimer
HEMATOLOGY|Sickling Test
HEMATOLOGY|G6PD
HEMATOLOGY|Hb Electrophoresis
HEMATOLOGY|HbA2
HEMATOLOGY|HbF
HEMATOLOGY|Direct Coombs Test
HEMATOLOGY|Indirect Coombs Test
SUGAR / DIABETES PROFILE|Fasting Blood Sugar (FBS)
SUGAR / DIABETES PROFILE|Random Blood Sugar (RBS)
SUGAR / DIABETES PROFILE|Post Prandial Blood Sugar (PPBS)
SUGAR / DIABETES PROFILE|HbA1c
SUGAR / DIABETES PROFILE|Estimated Average Glucose (eAG)
SUGAR / DIABETES PROFILE|Glucose Tolerance Test (GTT)
SUGAR / DIABETES PROFILE|Fasting Insulin
SUGAR / DIABETES PROFILE|C-Peptide
SUGAR / DIABETES PROFILE|Fructosamine
LIVER FUNCTION TEST (LFT)|Total Bilirubin
LIVER FUNCTION TEST (LFT)|Direct Bilirubin
LIVER FUNCTION TEST (LFT)|Indirect Bilirubin
LIVER FUNCTION TEST (LFT)|SGOT / AST
LIVER FUNCTION TEST (LFT)|SGPT / ALT
LIVER FUNCTION TEST (LFT)|Alkaline Phosphatase (ALP)
LIVER FUNCTION TEST (LFT)|Gamma GT (GGT)
LIVER FUNCTION TEST (LFT)|Total Protein
LIVER FUNCTION TEST (LFT)|Albumin
LIVER FUNCTION TEST (LFT)|Globulin
LIVER FUNCTION TEST (LFT)|A/G Ratio
LIVER FUNCTION TEST (LFT)|LDH
LIVER FUNCTION TEST (LFT)|Serum Ammonia
KIDNEY FUNCTION TEST (KFT / RFT)|Blood Urea
KIDNEY FUNCTION TEST (KFT / RFT)|BUN
KIDNEY FUNCTION TEST (KFT / RFT)|Serum Creatinine
KIDNEY FUNCTION TEST (KFT / RFT)|Uric Acid
KIDNEY FUNCTION TEST (KFT / RFT)|eGFR
KIDNEY FUNCTION TEST (KFT / RFT)|BUN / Creatinine Ratio
KIDNEY FUNCTION TEST (KFT / RFT)|Microalbumin
KIDNEY FUNCTION TEST (KFT / RFT)|Cystatin C
LIPID PROFILE|Total Cholesterol
LIPID PROFILE|Triglycerides
LIPID PROFILE|HDL Cholesterol
LIPID PROFILE|LDL Cholesterol
LIPID PROFILE|VLDL Cholesterol
LIPID PROFILE|Non-HDL Cholesterol
LIPID PROFILE|Cholesterol / HDL Ratio
LIPID PROFILE|LDL / HDL Ratio
THYROID PROFILE|T3
THYROID PROFILE|T4
THYROID PROFILE|TSH
THYROID PROFILE|FT3
THYROID PROFILE|FT4
THYROID PROFILE|Anti-TPO Antibody
THYROID PROFILE|Anti-Thyroglobulin Antibody
THYROID PROFILE|Thyroglobulin
THYROID PROFILE|TSH Receptor Antibody (TRAb)
ELECTROLYTES AND MINERALS|Sodium
ELECTROLYTES AND MINERALS|Potassium
ELECTROLYTES AND MINERALS|Chloride
ELECTROLYTES AND MINERALS|Calcium
ELECTROLYTES AND MINERALS|Ionized Calcium
ELECTROLYTES AND MINERALS|Phosphorus
ELECTROLYTES AND MINERALS|Magnesium
ELECTROLYTES AND MINERALS|Zinc
ELECTROLYTES AND MINERALS|Copper
ELECTROLYTES AND MINERALS|Serum Iron
ELECTROLYTES AND MINERALS|TIBC
ELECTROLYTES AND MINERALS|UIBC
ELECTROLYTES AND MINERALS|Transferrin
ELECTROLYTES AND MINERALS|Transferrin Saturation
VITAMIN PROFILE|Vitamin B12
VITAMIN PROFILE|Vitamin D (25-OH)
VITAMIN PROFILE|Vitamin D3
VITAMIN PROFILE|Vitamin D2
VITAMIN PROFILE|Vitamin A
VITAMIN PROFILE|Vitamin E
VITAMIN PROFILE|Vitamin K
VITAMIN PROFILE|Vitamin B1
VITAMIN PROFILE|Vitamin B2
VITAMIN PROFILE|Vitamin B3
VITAMIN PROFILE|Vitamin B5
VITAMIN PROFILE|Vitamin B6
VITAMIN PROFILE|Vitamin B7 (Biotin)
VITAMIN PROFILE|Folate / Folic Acid
VITAMIN PROFILE|Vitamin C
CARDIAC PROFILE|Troponin I
CARDIAC PROFILE|Troponin T
CARDIAC PROFILE|CK-MB
CARDIAC PROFILE|CPK Total
CARDIAC PROFILE|NT-proBNP
CARDIAC PROFILE|BNP
CARDIAC PROFILE|Homocysteine
CARDIAC PROFILE|Myoglobin
IRON PROFILE|Ferritin
HORMONE PROFILE|FSH
HORMONE PROFILE|LH
HORMONE PROFILE|Prolactin
HORMONE PROFILE|Total Testosterone
HORMONE PROFILE|Free Testosterone
HORMONE PROFILE|Estradiol (E2)
HORMONE PROFILE|Progesterone
HORMONE PROFILE|DHEA-S
HORMONE PROFILE|AMH
HORMONE PROFILE|Cortisol
HORMONE PROFILE|ACTH
HORMONE PROFILE|Insulin
HORMONE PROFILE|PTH
HORMONE PROFILE|Growth Hormone (GH)
HORMONE PROFILE|IGF-1
HORMONE PROFILE|Beta HCG
HORMONE PROFILE|Aldosterone
HORMONE PROFILE|Renin
HORMONE PROFILE|DHT
HORMONE PROFILE|SHBG
HORMONE PROFILE|Androstenedione
SEROLOGY / INFECTION PROFILE|CRP
SEROLOGY / INFECTION PROFILE|hs-CRP
SEROLOGY / INFECTION PROFILE|ASO
SEROLOGY / INFECTION PROFILE|Rheumatoid Factor (RF)
SEROLOGY / INFECTION PROFILE|VDRL
SEROLOGY / INFECTION PROFILE|TPHA
SEROLOGY / INFECTION PROFILE|HIV 1 & 2
SEROLOGY / INFECTION PROFILE|HBsAg
SEROLOGY / INFECTION PROFILE|Anti-HCV
SEROLOGY / INFECTION PROFILE|Dengue NS1
SEROLOGY / INFECTION PROFILE|Dengue IgG
SEROLOGY / INFECTION PROFILE|Dengue IgM
SEROLOGY / INFECTION PROFILE|Chikungunya IgM
SEROLOGY / INFECTION PROFILE|Malaria Antigen
SEROLOGY / INFECTION PROFILE|Widal Test
SEROLOGY / INFECTION PROFILE|Weil-Felix
SEROLOGY / INFECTION PROFILE|H. Pylori IgG
SEROLOGY / INFECTION PROFILE|H. Pylori IgM
SEROLOGY / INFECTION PROFILE|Typhoid IgM
SEROLOGY / INFECTION PROFILE|Leptospira IgM
SEROLOGY / INFECTION PROFILE|Scrub Typhus IgM
SEROLOGY / INFECTION PROFILE|Rubella IgG
SEROLOGY / INFECTION PROFILE|Rubella IgM
SEROLOGY / INFECTION PROFILE|CMV IgG
SEROLOGY / INFECTION PROFILE|CMV IgM
SEROLOGY / INFECTION PROFILE|HSV 1 IgG
SEROLOGY / INFECTION PROFILE|HSV 1 IgM
SEROLOGY / INFECTION PROFILE|HSV 2 IgG
SEROLOGY / INFECTION PROFILE|HSV 2 IgM
SEROLOGY / INFECTION PROFILE|Toxoplasma IgG
SEROLOGY / INFECTION PROFILE|Toxoplasma IgM
IMMUNOLOGY PROFILE|ANA
IMMUNOLOGY PROFILE|ANCA
IMMUNOLOGY PROFILE|Anti-dsDNA
IMMUNOLOGY PROFILE|Anti-CCP
IMMUNOLOGY PROFILE|C3
IMMUNOLOGY PROFILE|C4
IMMUNOLOGY PROFILE|IgG
IMMUNOLOGY PROFILE|IgA
IMMUNOLOGY PROFILE|IgM
IMMUNOLOGY PROFILE|Total IgE
IMMUNOLOGY PROFILE|IgG Subclasses
IMMUNOLOGY PROFILE|Anti-Cardiolipin Antibody
IMMUNOLOGY PROFILE|Lupus Anticoagulant
IMMUNOLOGY PROFILE|Beta-2 Glycoprotein Antibody
PANCREATIC PROFILE|Serum Amylase
PANCREATIC PROFILE|Serum Lipase
PANCREATIC PROFILE|Pancreatic Amylase
PANCREATIC PROFILE|Pancreatic Elastase
TUMOR MARKERS|PSA Total
TUMOR MARKERS|Free PSA
TUMOR MARKERS|CEA
TUMOR MARKERS|AFP
TUMOR MARKERS|CA-125
TUMOR MARKERS|CA 19-9
TUMOR MARKERS|CA 15-3
TUMOR MARKERS|CA 72-4
TUMOR MARKERS|Calcitonin
BLOOD GROUP PROFILE|ABO Blood Group
BLOOD GROUP PROFILE|Rh Typing
BLOOD GROUP PROFILE|Cross Matching
BLOOD GROUP PROFILE|Antibody Screening
BLOOD GROUP PROFILE|Antibody Identification
SPECIAL TESTS|Procalcitonin
SPECIAL TESTS|IL-6
SPECIAL TESTS|Lactate
SPECIAL TESTS|Blood Gas Analysis (ABG)
SPECIAL TESTS|Ammonia
SPECIAL TESTS|Osmolality
SPECIAL TESTS|Serum Ketone
SPECIAL TESTS|Beta-Hydroxybutyrate
SPECIAL TESTS|Ceruloplasmin
SPECIAL TESTS|Lead
SPECIAL TESTS|Arsenic
SPECIAL TESTS|Lithium
SPECIAL TESTS|Digoxin
SPECIAL TESTS|Valproic Acid
SPECIAL TESTS|Carbamazepine
SPECIAL TESTS|Phenytoin
SPECIAL TESTS|Tacrolimus
SPECIAL TESTS|Cyclosporine"""

def conn():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; c.execute("PRAGMA foreign_keys=ON"); return c
def init():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS patients(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,age TEXT,sex TEXT,phone TEXT,address TEXT,created_at TEXT);
        CREATE TABLE IF NOT EXISTS tests(id INTEGER PRIMARY KEY AUTOINCREMENT,test_name TEXT NOT NULL,unit TEXT DEFAULT '',reference_range TEXT DEFAULT '',category TEXT DEFAULT 'Other');
        CREATE TABLE IF NOT EXISTS reports(id INTEGER PRIMARY KEY AUTOINCREMENT,patient_id INTEGER NOT NULL,report_date TEXT NOT NULL,notes TEXT DEFAULT '',FOREIGN KEY(patient_id) REFERENCES patients(id));
        CREATE TABLE IF NOT EXISTS results(id INTEGER PRIMARY KEY AUTOINCREMENT,report_id INTEGER NOT NULL,test_id INTEGER NOT NULL,result_value TEXT DEFAULT '',FOREIGN KEY(report_id) REFERENCES reports(id),FOREIGN KEY(test_id) REFERENCES tests(id));
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT DEFAULT '');
        """)
        for line in CATALOG.splitlines():
            if "|" in line:
                cat,name=line.split("|",1)
                c.execute("INSERT OR IGNORE INTO tests(test_name,category) SELECT ?,? WHERE NOT EXISTS(SELECT 1 FROM tests WHERE lower(test_name)=lower(?))",(name,cat,name))
        defaults={"lab_name":"SHREE SHYAM PATHOLOGY LAB","address":"","phone":"","letterhead":""}
        for k,v in defaults.items(): c.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)",(k,v))
def setting(k):
    with conn() as c:
        r=c.execute("SELECT value FROM settings WHERE key=?",(k,)).fetchone()
        return r["value"] if r else ""
def login_required(f):
    @wraps(f)
    def w(*a,**kw):
        if not session.get("ok"): return redirect(url_for("login"))
        return f(*a,**kw)
    return w
@app.context_processor
def common():
    return {"lab_name":setting("lab_name"),"lab_phone":setting("phone")}
@app.route("/login",methods=["GET","POST"])
def login():
    if request.method=="POST":
        if secrets.compare_digest(request.form.get("password",""),ADMIN_PASSWORD):
            session["ok"]=True; return redirect(url_for("index"))
        flash("गलत पासवर्ड")
    return render_template("login.html")
@app.get("/logout")
def logout(): session.clear(); return redirect(url_for("login"))
@app.get("/")
@login_required
def index():
    with conn() as c:
        patients=c.execute("SELECT * FROM patients ORDER BY id DESC LIMIT 10").fetchall()
        counts=[c.execute("SELECT count(*) FROM "+t).fetchone()[0] for t in ("patients","tests","reports")]
    return render_template("index.html",patients=patients,counts=counts)
@app.route("/patients",methods=["GET","POST"])
@login_required
def patients():
    with conn() as c:
        if request.method=="POST":
            name=request.form.get("name","").strip()
            if name: c.execute("INSERT INTO patients(name,age,sex,phone,address,created_at) VALUES(?,?,?,?,?,?)",(name,request.form.get("age",""),request.form.get("sex",""),request.form.get("phone",""),request.form.get("address",""),datetime.now().strftime("%Y-%m-%d %H:%M")))
            return redirect(url_for("patients"))
        rows=c.execute("SELECT * FROM patients ORDER BY id DESC").fetchall()
    return render_template("patients.html",patients=rows)
@app.route("/tests",methods=["GET","POST"])
@login_required
def tests():
    with conn() as c:
        if request.method=="POST":
            name=request.form.get("test_name","").strip()
            if name: c.execute("INSERT INTO tests(test_name,unit,reference_range,category) VALUES(?,?,?,?)",(name,request.form.get("unit",""),request.form.get("reference_range",""),request.form.get("category","Other")))
            return redirect(url_for("tests"))
        rows=c.execute("SELECT * FROM tests ORDER BY category,test_name").fetchall()
    return render_template("tests.html",tests=rows)
@app.post("/tests/<int:tid>/update")
@login_required
def update_test(tid):
    with conn() as c:
        c.execute("UPDATE tests SET unit=?,reference_range=? WHERE id=?",(request.form.get("unit",""),request.form.get("reference_range",""),tid))
    return redirect(url_for("tests"))
@app.route("/reports/new",methods=["GET","POST"])
@login_required
def new_report():
    with conn() as c:
        pats=c.execute("SELECT * FROM patients ORDER BY name").fetchall()
        ts=c.execute("SELECT * FROM tests ORDER BY category,test_name").fetchall()
        if request.method=="POST":
            pid=request.form.get("patient_id")
            if not pid: flash("पहले मरीज चुनें"); return redirect(url_for("new_report"))
            cur=c.execute("INSERT INTO reports(patient_id,report_date,notes) VALUES(?,?,?)",(pid,request.form.get("report_date") or datetime.now().strftime("%Y-%m-%d"),request.form.get("notes","")))
            rid=cur.lastrowid
            for t in ts:
                val=request.form.get("result_"+str(t["id"]),"").strip()
                if val: c.execute("INSERT INTO results(report_id,test_id,result_value) VALUES(?,?,?)",(rid,t["id"],val))
            return redirect(url_for("view_report",rid=rid))
    return render_template("new_report.html",patients=pats,tests=ts,today=datetime.now().strftime("%Y-%m-%d"))
@app.get("/reports/<int:rid>")
@login_required
def view_report(rid):
    with conn() as c:
        r=c.execute("SELECT reports.*,patients.name,patients.age,patients.sex,patients.phone,patients.address FROM reports JOIN patients ON patients.id=reports.patient_id WHERE reports.id=?",(rid,)).fetchone()
        if not r: return "Report not found",404
        results=c.execute("SELECT tests.test_name,tests.unit,tests.reference_range,results.result_value FROM results JOIN tests ON tests.id=results.test_id WHERE report_id=? ORDER BY tests.category,tests.test_name",(rid,)).fetchall()
    return render_template("report.html",r=r,results=results,letterhead=setting("letterhead"),address=setting("address"),phone=setting("phone"))
@app.route("/settings",methods=["GET","POST"])
@login_required
def settings():
    if request.method=="POST":
        with conn() as c:
            for k in ("lab_name","address","phone"): c.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(k,request.form.get(k,"")))
            f=request.files.get("letterhead")
            if f and f.filename:
                ext=os.path.splitext(secure_filename(f.filename))[1].lower()
                if ext not in (".png",".jpg",".jpeg",".webp"): flash("Letterhead केवल PNG/JPG/WEBP होना चाहिए"); return redirect(url_for("settings"))
                name="letterhead"+ext; f.save(os.path.join(UPLOAD,name))
                c.execute("INSERT INTO settings(key,value) VALUES('letterhead',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(name,))
        flash("सेटिंग सेव हो गई"); return redirect(url_for("settings"))
    return render_template("settings.html",lab=setting("lab_name"),address=setting("address"),phone=setting("phone"),letterhead=setting("letterhead"))
@app.get("/uploads/<path:name>")
@login_required
def uploads(name): return send_from_directory(UPLOAD,name)
init()
if __name__=="__main__": app.run(host="0.0.0.0",port=int(os.environ.get("PORT",5000)),debug=False)
