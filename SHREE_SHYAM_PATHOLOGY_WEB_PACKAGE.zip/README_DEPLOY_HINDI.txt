SHREE SHYAM PATHOLOGY LAB - WEB EDITION
========================================

Responsive Flask web application for Android Chrome and Windows browsers.

LOCAL TEST
1. Install Python 3.10+
2. Open terminal in this folder
3. python -m pip install -r requirements.txt
4. Set ADMIN_PASSWORD and SECRET_KEY environment variables
5. python app.py
6. Open http://127.0.0.1:5000

PUBLIC INTERNET DEPLOYMENT
- This package is prepared for Render using render.yaml.
- Create a Render account, create a new Blueprint from this folder/repository,
  and deploy. Set ADMIN_PASSWORD to a strong unique password when prompted.
- Persistent disk is configured at /var/data for the SQLite database and letterhead.
- You must connect a Git repository or upload these files through Render's supported
  deployment flow. This ZIP alone does not create a public website or domain.
- Use HTTPS, a strong unique admin password, and restrict access to authorized staff.
- Back up /var/data/pathology_lab.db and /var/data/uploads regularly.

FEATURES
- Patient registration and list
- Seeded test catalog from the supplied Windows version
- Add tests and enter lab-verified unit/reference intervals
- Create reports and enter results
- Print / Save as PDF from browser
- Change lab name, address, phone and upload letterhead/logo
- Responsive interface for mobile and desktop

IMPORTANT
- Default local password is ChangeMe123! Change it before any public deployment.
- Do not use default credentials on the public internet.
- This is a starter app, not a validated medical device or complete LIS/LIMS.
- Configure backups, access controls and privacy/security procedures before real patient use.
- Reference intervals are blank by design and must be verified for your laboratory,
  method, analyzer, age and sex. Qualified staff must review every result and report.
- Public deployment handles sensitive patient information. HTTPS and strong passwords
  are essential; consider a professional security review before production use.
